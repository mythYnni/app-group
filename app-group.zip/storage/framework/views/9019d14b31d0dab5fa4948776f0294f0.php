<?php
    use Carbon\Carbon;
?>
<?php $__env->startSection('css_view'); ?>
    <?php echo $__env->make('FEadmin.Layout.Head.css_tableButton_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('FEadmin.Layout.Head.js_tableButton_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php
    $typeHTML = [
        0 => ['name' => 'Riêng Tư', 'color' => 'bg-pink-900'],
        1 => ['name' => 'Công Khai', 'color' => 'bg-purple-900'],
    ];

    $statusHTML = [
        0 => ['name' => 'Hiển Thị', 'color' => 'bg-cyan-900'],
        1 => ['name' => 'Lưu trữ', 'color' => 'bg-gray-800'],
    ];

    $statusColor_HTML = [
        0 => ['color' => '#00874e87', 'background' => '#00874e87'],
        1 => ['color' => '#f1f708', 'background' => '#dbf70854'],
        2 => ['color' => '#ff0000', 'background' => '#e7000069'],
    ];
?>
<?php $__env->startSection('view'); ?>
    <div class="pc-content">
        <!-- [ breadcrumb ] start -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Trang Chủ</a></li>
                            <li class="breadcrumb-item"><a href="javascript: void(0)">Hệ Thống</a></li>
                            <li class="breadcrumb-item"><a href="javascript: void(0)">Group</a></li>
                            <li class="breadcrumb-item" aria-current="page">Danh Sách Nhóm Tương Tác Tốt</li>
                        </ul>
                    </div>
                    <div class="col-md-12">
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- [ breadcrumb ] end -->
        <!-- [ Main Content ] start -->
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <h5>Danh Sách Hội Nhóm Tương Tác Tốt</h5>
                    </div>
                    <div class="card-body">
                        <div class="dt-responsive table-responsive">
                            <table id="cbtn-selectors" class="table table-striped table-bordered nowrap">
                                <thead>
                                    <tr>
                                        <th>Mã Nhóm</th>
                                        <th>Tên Nhóm</th>
                                        <th>Danh Mục</th>
                                        <th>Giá Thuê</th>
                                        <th>Giá Bán</th>
                                        <th>Số Lượng Thành Viên</th>
                                        <th>Thành Viên/Tuần</th>
                                        <th>Bài Viết/Tuần</th>
                                        <th>Số Lượng Người Thuê</th>
                                        <th>Loại Nhóm</th>
                                        <th>Quản Trị Nhóm</th>
                                        <th>Vị Trí</th>
                                        <th>Tỉnh Thành</th>
                                        <th>Quận/Huyện</th>
                                        <th>Phường/Xã</th>
                                        <th>Tình Trạng</th>
                                        <th>Sale</th>
                                        <th>Người Tạo</th>
                                        <th>Tính Năng</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $type = $typeHTML[$value->type] ?? [
                                                'name' => 'Không Xác Định',
                                                'color' => '#000000',
                                            ];
                                            $typeName = $type['name'];
                                            $typeColor = $type['color'];
                                        ?>
                                        <?php
                                            $status_color = $statusColor_HTML[$value->status_color] ?? [
                                                'background' => '#000000',
                                            ];
                                            $color_backgroup = $status_color['background'];
                                        ?>
                                        <?php
                                            $status_type = $statusHTML[$value->status] ?? [
                                                'name' => 'Không Xác Định',
                                                'color' => '#000000',
                                            ];
                                            $statusName = $status_type['name'];
                                            $statusColor = $status_type['color'];
                                        ?>
                                        <tr style="background-color: <?php echo e($color_backgroup); ?>">
                                            <td><?php echo e($value->code); ?></td>
                                            <td><a href="<?php echo e($value->linkGroup); ?>" target="_blank"><span><?php echo e($value->nameGroup); ?></span></a></td>
                                            <td><?php echo e($value->category); ?></td>
                                            <td><?php echo e(number_format($value->rent_cost, 0, ',', '.')); ?></td>
                                            <td><?php echo e(number_format($value->price, 0, ',', '.')); ?></td>
                                            <td><?php echo e($value->account_group); ?> thành viên</td>
                                            <td><?php echo e($value->account_group_week); ?> người / 1 tuần</td>
                                            <td><?php echo e($value->account_group_blog); ?> bài / 1 tuần</td>
                                            <td><?php echo e($value->rentals); ?> khách</td>
                                            <td><span
                                                    class="badge rounded-pill <?php echo e($typeColor); ?>"><?php echo e($typeName); ?></span>
                                            </td>
                                            <td style="max-width: 200px;">
                                                <div style="white-space: normal;">
                                                    <?php
                                                        $admin = json_decode($value->name_user_group);
                                                    ?>
                                                    <?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <a href="<?php echo e($obj->linkFacebook); ?>" target="_blank" class="badge bg-light-primary"><?php echo e($obj->name); ?></a>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </td>
                                            <td><?php echo e($value->objCategory->name); ?></td>
                                            <td><?php echo e($value->province); ?></td>
                                            <td><?php echo e($value->district); ?></td>
                                            <td><?php echo e($value->wards); ?></td>
                                            <td><span
                                                    class="badge rounded-pill <?php echo e($statusColor); ?>"><?php echo e($statusName); ?></span>
                                            </td>
                                            <td style="max-width: 200px;">
                                                <div style="white-space: normal;">
                                                    <?php
                                                        $adminSale = json_decode($value->name_user_sale);
                                                    ?>
                                                    <?php $__currentLoopData = $adminSale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $objs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <span class="badge bg-light-primary"><?php echo e($objs->name); ?></span>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </td>
                                            <td><?php echo e($value->user_create); ?> - <?php echo e($value->user_email_create); ?> <br />
                                                <?php echo e(Carbon::parse($value->timeCreate)->locale('vi')->isoFormat('Do [tháng] M [năm] YYYY, H:mm:ss A')); ?>

                                            </td>
                                            <td class="action">
                                                <div class="btn-group-dropdown">
                                                  <button class="btn btn-outline-secondary dropdown-toggle btn-sm mg-button-left" type="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Lựa chọn</button>
                                                  <div class="dropdown-menu">
                                                    <a class="dropdown-item" href="<?php echo e(route('delete_group', $value->slugGroup)); ?>" title="Delete" onclick="return confirm('Bạn Có Chắc Muốn Xóa Nhóm <?php echo e($value->nameGroup); ?> Không?')">
                                                      <span style="display: flex; justify-content: flex-start; color: #dc2626;"><i class="ti ti-trash me-1"></i> Xóa</span>
                                                    </a>
                                                    <a class="dropdown-item" href="<?php echo e(route('view_update_group', $value->slugGroup)); ?>"><span style="display: flex; justify-content: flex-start; color: #2ca87f;"><i class="ti ti-pencil me-1"></i> Cập Nhật</span></a>
                                                  </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td>Mã Nhóm</td>
                                        <td>Tên Nhóm</td>
                                        <td>Danh Mục</td>
                                        <td>Giá Thuê</td>
                                        <td>Giá Bán</td>
                                        <td>Số Lượng Thành Viên</td>
                                        <td>Thành Viên/Tuần</td>
                                        <td>Bài Viết/Tuần</td>
                                        <td>Số Lượng Người Thuê</td>
                                        <td>Loại Nhóm</td>
                                        <td>Quản Trị</td>
                                        <td>Vị Trí</td>
                                        <td>Tỉnh Thành</td>
                                        <td>Quận/Huyện</td>
                                        <td>Phường/Xã</td>
                                        <td>Tình Trạng</td>
                                        <td>Người Tạo</td>
                                        <td>Tính Năng</td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('view_js'); ?>
    <?php echo $__env->make('FEadmin.Layout.Fooder.js_fooder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('FEadmin.Layout.Fooder.js_tableButton_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('FEadmin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web_for_group\app-group\resources\views/FEadmin/Pages/Group/view_list_interact.blade.php ENDPATH**/ ?>