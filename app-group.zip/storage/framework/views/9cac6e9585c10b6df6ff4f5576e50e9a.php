<div class="loader-bg">
    <div class="loader-track">
        <div class="loader-fill"></div>
    </div>
</div><?php /**PATH D:\web_for_group\app-group\resources\views/FEadmin/Layout/Body/pre_loader.blade.php ENDPATH**/ ?>