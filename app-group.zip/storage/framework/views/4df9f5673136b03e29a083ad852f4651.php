<?php if(Session::get('error')): ?>
    <script>
        swal(
            "<?php echo e(Session::get('error')); ?>", "Thông Báo Từ Hệ Thống!", 'error', {
                button: true,
                button: "OK",
                timer: 50000,
                dangerMode: true,
            })
    </script>
<?php endif; ?>
<?php /**PATH D:\web_for_group\app-group\resources\views/FEadmin/Sweetalert/error.blade.php ENDPATH**/ ?>