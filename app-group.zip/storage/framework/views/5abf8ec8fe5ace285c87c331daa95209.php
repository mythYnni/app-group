<?php $__env->startSection('css_view'); ?>
    <?php echo $__env->make('FEadmin.Layout.Head.css_create_group', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('FEadmin.Layout.Head.js_create_group', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('view'); ?>
    <div class="pc-content">
        <!-- [ breadcrumb ] start -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Trang Chủ</a></li>
                            <li class="breadcrumb-item"><a href="javascript: void(0)">Hệ Thống</a></li>
                            <li class="breadcrumb-item"><a href="javascript: void(0)">Group</a></li>
                            <li class="breadcrumb-item" aria-current="page">Thêm Mới</li>
                        </ul>
                    </div>
                    <div class="col-md-12">
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- [ breadcrumb ] end -->
        <!-- [ Main Content ] start -->
        <div class="row">
            <div class="col-sm-12">
                <!-- Basic Inputs -->
                <form class="card" action="<?php echo e(route('creater_group')); ?>" enctype="multipart/form-data" method="POST"
                    id="formReset">
                    <?php echo csrf_field(); ?>
                    <div class="card-header">
                        <h5>Thêm Mới Hội Nhóm</h5>
                    </div>
                    <div class="card-body row">
                        <div class="form-group col-12 col-md-2">
                            <label class="form-label">Mã Nhóm</label>
                            <input type="text" class="form-control form-control" placeholder="Mã Nhóm"
                                fdprocessedid="w3ptog" name="code" value="<?php echo e(old('code')); ?>">
                            <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small style="color: #f33923;"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-12 col-md-5">
                            <label class="form-label">Tên Hội Nhóm</label>
                            <input type="text" class="form-control form-control" placeholder="Tên Nhóm"
                                onkeyup="ChangeToSlug();" fdprocessedid="w3ptog" name="nameGroup" id="slug"
                                value="<?php echo e(old('nameGroup')); ?>">
                            <?php $__errorArgs = ['nameGroup'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small style="color: #f33923;"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <?php $__errorArgs = ['slugGroup'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small style="color: #f33923;"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-12 col-md-5">
                            <label class="form-label">Đường dẫn sạch</label>
                            <input type="text" class="form-control" name="slugGroup" value="<?php echo e(old('slugGroup')); ?>"
                                id="convert_slug" placeholder="Đường dẫn sạch" readonly fdprocessedid="qaalh">
                        </div>
                        <div class="form-group col-12 col-md-4">
                            <label class="form-label" for="exampleSelect1">Quản Trị</label>
                            <select class="form-control" name="name_user_group[]" id="choices-multiple-groups" multiple>
                                <optgroup label="Quản Trị Nhóm">
                                    <?php $__currentLoopData = $listAdmin->sortBy('fullName'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value->id); ?>"
                                            <?php echo e(old('name_user_group') && in_array($value->id, old('name_user_group')) ? 'selected' : ''); ?>>
                                            <?php echo e($value->fullName); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </optgroup>
                            </select>
                            <?php $__errorArgs = ['name_user_group'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small style="color: #f33923;"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-12 col-md-3">
                            <label class="form-label" for="exampleSelect1">Sale</label>
                            <select class="form-control" name="name_user_sale[]" id="choices-multiple-groups-admin"
                                multiple>
                                <optgroup label="Quản Trị">
                                    <?php $__currentLoopData = $listAccount->sortBy('fullName'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($value->decentralization == 0): ?>
                                            <option value="<?php echo e($value->id); ?>"
                                                <?php echo e(old('name_user_sale') && in_array($value->id, old('name_user_sale')) ? 'selected' : ''); ?>>
                                                <?php echo e($value->fullName); ?>

                                            </option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </optgroup>
                                <optgroup label="Nhân Sự">
                                    <?php $__currentLoopData = $listAccount->sortBy('fullName'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($value->decentralization == 1): ?>
                                            <option value="<?php echo e($value->id); ?>"
                                                <?php echo e(old('name_user_sale') && in_array($value->id, old('name_user_sale')) ? 'selected' : ''); ?>>
                                                <?php echo e($value->fullName); ?>

                                            </option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </optgroup>
                            </select>
                        </div>
                        <div class="form-group col-12 col-md-3">
                            <label class="form-label">Link Group</label>
                            <input type="text" class="form-control form-control" placeholder="Link"
                                fdprocessedid="w3ptog" name="linkGroup" value="<?php echo e(old('linkGroup')); ?>">
                            <?php $__errorArgs = ['linkGroup'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small style="color: #f33923;"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-12 col-md-2">
                            <label class="form-label">Danh Mục Loại Nhóm</label>
                            <input type="text" class="form-control form-control" placeholder="Danh Mục"
                                fdprocessedid="w3ptog" name="category" id="category" value="<?php echo e(old('category')); ?>">
                            <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small style="color: #f33923;"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-12 col-md-3">
                            <label class="form-label" for="exampleSelect1">Vị Trí</label>
                            <select class="form-select" id="exampleSelect1" name="idCategory">
                                <?php $__currentLoopData = $listCategory->sortBy('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($value->status == 0): ?>
                                        <option value="<?php echo e($value->id); ?>"
                                            <?php if($value->id == old('idCategory')): ?> selected <?php endif; ?>>
                                            <?php echo e($value->name); ?>

                                        </option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['idCategory'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small style="color: #f33923;"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-12 col-md-3">
                            <label class="form-label">Tỉnh Thành</label>
                            <select class="form-select" id="city" name="province">
                                <option value="" selected>Chọn Tỉnh Thành/ Thành Phố</option>
                            </select>
                            <?php $__errorArgs = ['province'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small style="color: #f33923;"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-12 col-md-3">
                            <label class="form-label">Quận/Huyện</label>
                            <select class="form-select" id="district" name="district">
                                <option value="" selected>Chọn Quận/Huyện</option>
                            </select>
                            <?php $__errorArgs = ['district'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small style="color: #f33923;"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-12 col-md-3">
                            <label class="form-label">Phường/Xã</label>
                            <select class="form-select" id="ward" name="wards">
                                <option value="" selected>Chọn Phường/Xã</option>
                            </select>
                            <?php $__errorArgs = ['wards'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small style="color: #f33923;"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-12 col-md-4">
                            <label class="form-label">Số Lượng Thành Viên</label>
                            <input type="text" class="form-control" name="account_group"
                                value="<?php echo e(old('account_group')); ?>" placeholder="Số Lượng Thành Viên"
                                fdprocessedid="qaalh">
                            <?php $__errorArgs = ['account_group'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small style="color: #f33923;"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-12 col-md-4">
                            <label class="form-label" for="example-quantity">Lượng Thành Viên/Tuần</label>
                            <input type="number" class="form-control" id="example-quantity" min="1"
                                value="<?php echo e(old('account_group_week')); ?>" name="account_group_week"
                                data-gtm-form-interact-field-id="1">
                            <?php $__errorArgs = ['account_group_week'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small style="color: #f33923;"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-12 col-md-4">
                            <label class="form-label" for="example-quantity">Lượng Bài Viết/Tuần</label>
                            <input type="number" class="form-control" id="example-quantity" min="1"
                                value="<?php echo e(old('account_group_blog')); ?>" name="account_group_blog"
                                data-gtm-form-interact-field-id="1">
                            <?php $__errorArgs = ['account_group_blog'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small style="color: #f33923;"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-12 col-md-6">
                            <label class="form-label">Giá Thuê</label>
                            <input type="text" class="form-control" name="rent_cost" id="rent_cost"
                                value="<?php echo e(old('rent_cost')); ?>" placeholder="Giá Thuê" fdprocessedid="qaalh">
                            <?php $__errorArgs = ['rent_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small style="color: #f33923;"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <small id="rent_cost_vnd" style="display: none;"></small>
                        </div>
                        <div class="form-group col-12 col-md-6">
                            <label class="form-label">Giá Bán</label>
                            <input type="text" class="form-control" name="price" id="price"
                                value="<?php echo e(old('price')); ?>" placeholder="Giá Bán" fdprocessedid="qaalh">
                            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small style="color: #f33923;"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <small id="price_vnd" style="display: none;"></small>
                        </div>
                        <div class="form-group col-12 col-md-6">
                            <label class="form-label" for="exampleSelect1">Phân Loại</label>
                            <select class="form-select" id="exampleSelect1" name="type_sale">
                                <option value="0" <?php echo e(old('type_sale') == 0 ? 'selected' : ''); ?>>Mặc Định</option>
                                <option value="1" <?php echo e(old('type_sale') == 1 ? 'selected' : ''); ?>>Nhóm Thuê Nhiều</option>
                                <option value="2" <?php echo e(old('type_sale') == 2 ? 'selected' : ''); ?>>Nhóm Tương Tác Tốt</option>
                            </select>
                            <?php $__errorArgs = ['type_sale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small style="color: #f33923;"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-12 col-md-6">
                            <label class="form-label" for="exampleSelect1">Ảnh Nhóm</label>
                            <div class="input-group">
                                <input type="file" class="form-control" id="inputGroupFile01" name="file">
                                <input type="text" class="form-control" id="imageURL" name="imageURL" value="<?php echo e(old('imageURL')); ?>" placeholder="Nhập đường dẫn ảnh từ Google hoặc trang web khác">
                            </div>
                            <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small style="color: #f33923;"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group row mb-0 col-12 col-md-4">
                            <label class="form-label">Loại Nhóm</label>
                            <div class="col-sm-12">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="type" value="0"
                                        id="customCheckinlhstate1" <?php echo e(old('type') == '0' ? 'checked' : ''); ?>

                                        data-gtm-form-interact-field-id="2">
                                    <label class="form-check-label" for="customCheckinlhstate1"> Riêng Tư </label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="type" value="1"
                                        id="customCheckinlhstate2" <?php echo e(old('type') == '1' ? 'checked' : ''); ?>

                                        data-gtm-form-interact-field-id="1">
                                    <label class="form-check-label" for="customCheckinlhstate2"> Công Khai </label>
                                </div>
                            </div>
                            <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small style="color: #f33923;"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group row mb-0 col-12 col-md-4">
                            <label class="form-label">Trạng Thái Nhóm</label>
                            <div class="col-sm-12">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="status_color" value="0"
                                        id="customCheckinlhstate3" <?php echo e(old('status_color') == '0' ? 'checked' : ''); ?>

                                        data-gtm-form-interact-field-id="2">
                                    <label class="form-check-label" for="customCheckinlhstate3"> Xanh </label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="status_color" value="1"
                                        id="customCheckinlhstate4" <?php echo e(old('status_color') == '1' ? 'checked' : ''); ?>

                                        data-gtm-form-interact-field-id="1">
                                    <label class="form-check-label" for="customCheckinlhstate4"> Vàng </label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="status_color" value="2"
                                        id="customCheckinlhstate5" <?php echo e(old('status_color') == '2' ? 'checked' : ''); ?>

                                        data-gtm-form-interact-field-id="1">
                                    <label class="form-check-label" for="customCheckinlhstate5"> Đỏ </label>
                                </div>
                            </div>
                            <?php $__errorArgs = ['status_color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small style="color: #f33923;"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group row mb-0 col-12 col-md-4">
                            <label class="form-label">Trạng Thái</label>
                            <div class="col-sm-12">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="status" value="0"
                                        id="customCheckinlhstate6" <?php echo e(old('status') == '0' ? 'checked' : ''); ?>

                                        data-gtm-form-interact-field-id="2">
                                    <label class="form-check-label" for="customCheckinlhstate6"> Hiển Thị </label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="status" value="1"
                                        id="customCheckinlhstate7" <?php echo e(old('status') == '1' ? 'checked' : ''); ?>

                                        data-gtm-form-interact-field-id="1">
                                    <label class="form-check-label" for="customCheckinlhstate7"> Lưu Trữ </label>
                                </div>
                            </div>
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small style="color: #f33923;"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-12 col-md-12"></div>
                        <div class="form-group col-12 col-md-12">
                            <label class="form-label" for="exampleFormControlTextarea1">Giới Thiệu</label>
                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="5" name="detail_group"><?php echo e(old('detail_group')); ?></textarea>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button class="btn btn-primary me-2" type="submit">Thêm Mới</button>
                        <button type="reset" class="btn btn-light" id="resetBtn">Đặt Lại</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('view_js'); ?>
    <?php echo $__env->make('FEadmin.Layout.JS.Change_to_slug', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('FEadmin.Layout.Fooder.js_create_group', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('FEadmin.Layout.JS.Reset_button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('FEadmin.Layout.JS.Drop_Account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('FEadmin.Layout.JS.Get_Account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('FEadmin.Layout.JS.Price', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        function loadImage() {
            var imageURL = document.getElementById('imageURL').value;
            var img = document.createElement('img');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('FEadmin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web_for_group\app-group\resources\views/FEadmin/Pages/Group/view_create.blade.php ENDPATH**/ ?>