
<?php $__env->startSection('css_view'); ?>
    <?php echo $__env->make('FEadmin.Layout.Head.css_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('FEadmin.Layout.Head.js_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('view'); ?>
    <div class="pc-content">
        <!-- [ breadcrumb ] start -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Trang Chủ</a></li>
                            <li class="breadcrumb-item"><a href="javascript: void(0)">Lỗi</a></li>
                            <li class="breadcrumb-item" aria-current="page">Lỗi Hệ Thống</li>
                        </ul>
                    </div>
                    <div class="col-md-12">
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- [ breadcrumb ] end -->
        <!-- [ Main Content ] start -->
        <div class="row">
            <div class="col-sm-12">
                <div class="card error-card">
                    <div class="card-body">
                        <div class="error-image-block">
                            <div class="row justify-content-center">
                                <div class="col-10">
                                    <img class="img-fluid" src="<?php echo e(url('assets')); ?>/images/pages/img-error-500.svg" alt="img">
                                </div>
                            </div>
                        </div>
                        <div class="text-center">
                            <h1 class="mt-4"><b>Lỗi máy chủ nội bộ</b></h1>
                            <p class="mt-2 mb-4 text-sm text-muted">Lỗi máy chủ 404. Chúng tôi đang khắc phục sự cố. vui lòng
                                thử lại ở giai đoạn sau.</p>
                            <a href="<?php echo e(route('view_home_admin')); ?>" class="btn btn-primary mb-3">Trang Chủ</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- [ Main Content ] end -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('view_js'); ?>
    <?php echo $__env->make('FEadmin.Layout.Fooder.js_fooder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('FEadmin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web_for_group\app-group\resources\views/FEadmin/Pages/Error/error404.blade.php ENDPATH**/ ?>