<script>
    document.getElementById('resetBtn').addEventListener('click', function() {
        document.getElementById('formReset').reset(); // Thay yourFormId bằng id của form của bạn
    });
</script>
<?php /**PATH D:\web_for_group\app-group\resources\views/FEadmin/Layout/JS/Reset_button.blade.php ENDPATH**/ ?>