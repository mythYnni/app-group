<?php
    use Carbon\Carbon;
?>
<?php $__env->startSection('css_view'); ?>
    <?php echo $__env->make('FEadmin.Layout.Head.css_dataTable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('view'); ?>
    <div class="pc-content">
        <!-- [ breadcrumb ] start -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Trang Chủ</a></li>
                            <li class="breadcrumb-item"><a href="javascript: void(0)">Hệ Thống</a></li>
                            <li class="breadcrumb-item"><a href="javascript: void(0)">Bài Viết</a></li>
                            <li class="breadcrumb-item" aria-current="page">Danh Sách</li>
                        </ul>
                    </div>
                    <div class="col-md-12">
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- [ breadcrumb ] end -->
        <!-- [ Main Content ] start -->
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12">
                <div class="card">
                    <div class="card-header">
                        <h5>Danh Sách Bài Viết</h5>
                    </div>
                    <div class="card-body">
                        <table id="res-config" class="display table table-striped table-hover dt-responsive nowrap"
                            style="width: 100%">
                            <thead>
                                <tr>
                                    <th>stt</th>
                                    <th>Tiêu Đề</th>
                                    <th>Ngày tạo</th>
                                    <th>Trạng thái</th>
                                    <th>Chức năng</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key + 1); ?></td>
                                        <td><?php echo e($value->name); ?></td>
                                        <td><?php echo e(Carbon::parse($value->timeCreate)->locale('vi')->isoFormat('Do [tháng] M [năm] YYYY, H:mm:ss A')); ?>

                                        </td>
                                        <td>
                                            <?php if(intval($value->status == 0)): ?>
                                                <span class="badge rounded-pill text-bg-success">Hiện</span>
                                            <?php else: ?>
                                                <span class="badge rounded-pill text-bg-warning text-dark">Ẩn</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="action">
                                            <div class="btn-group-dropdown">
                                                <button
                                                    class="btn btn-outline-secondary dropdown-toggle btn-sm mg-button-left"
                                                    type="button" data-bs-toggle="dropdown" aria-haspopup="true"
                                                    aria-expanded="false">Lựa chọn</button>
                                                <div class="dropdown-menu">
                                                    <a class="dropdown-item text-inverse pr-10 blog_detail"
                                                        data-id="<?php echo e($value->slug); ?>" data-toggle="tooltip" title="Edit">
                                                        <span
                                                            style="display: flex; justify-content: flex-start; color: #2686dc;"><i
                                                                class="ti ti-eye me-1"></i> Xem</span>
                                                    </a>
                                                    <a class="dropdown-item" href="<?php echo e(route('delete_blog', $value->slug)); ?>"
                                                        title="Delete"
                                                        onclick="return confirm('Bạn Có Chắc Muốn <?php echo e($value->name); ?> Không?')">
                                                        <span
                                                            style="display: flex; justify-content: flex-start; color: #dc2626;"><i
                                                                class="ti ti-trash me-1"></i> Xóa</span>
                                                    </a>
                                                    <a class="dropdown-item"
                                                        href="<?php echo e(route('view_update_blog', $value->slug)); ?>"><span
                                                            style="display: flex; justify-content: flex-start; color: #2ca87f;"><i
                                                                class="ti ti-pencil me-1"></i> Cập Nhật</span></a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('FEadmin.Layout.Body.modal_detail_blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('view_js'); ?>
    <?php echo $__env->make('FEadmin.Layout.JS.modal_blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('FEadmin.Layout.Fooder.js_dataTable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('FEadmin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web_for_group\app-group\resources\views/FEadmin/Pages/Blog/view_list.blade.php ENDPATH**/ ?>