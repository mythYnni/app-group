
<?php $__env->startSection('css_view'); ?>
    <?php echo $__env->make('FEadmin.Layout.Head.css_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('FEadmin.Layout.Head.js_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('view'); ?>
    <div class="pc-content">
        <!-- [ breadcrumb ] start -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Trang Chủ</a></li>
                            <li class="breadcrumb-item"><a href="javascript: void(0)">Hồ Sơ</a></li>
                            <li class="breadcrumb-item" aria-current="page">Thông Tin Cá Nhân</li>
                        </ul>
                    </div>
                    <div class="col-md-12">
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- [ breadcrumb ] end -->
        <!-- [ Main Content ] start -->
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-body py-0">
                        <ul class="nav nav-tabs profile-tabs" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="profile-tab-1" data-bs-toggle="tab" href="#profile-1"
                                    role="tab" aria-selected="true">
                                    <i class="ti ti-user me-2"></i>Hồ Sơ
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="tab-content">
                    <div class="tab-pane show active" id="profile-1" role="tabpanel" aria-labelledby="profile-tab-1">
                        <div class="row">
                            <div class="col-lg-4 col-xxl-3">
                                <div class="card">
                                    <div class="card-body position-relative">
                                        <div class="position-absolute end-0 top-0 p-3">
                                            <span class="badge bg-primary"><?php echo e(Auth::guard('admin')->user()->decentralization == '0' ? 'Quản trị' : 'Nhân sự'); ?></span>
                                        </div>
                                        <div class="text-center mt-3">
                                            <div class="chat-avtar d-inline-flex mx-auto">
                                                <img class="rounded-circle img-fluid wid-70"
                                                    src="<?php echo e(url('assets')); ?>/images/user/avatar-1.jpg" alt="User image">
                                            </div>
                                            <h5 class="mb-0"><?php echo e(Auth::guard('admin')->user()->fullName); ?></h5>
                                            <p class="text-muted text-sm">Tài Khoản Quyền Quản Trị</p>
                                            <hr class="my-3 border border-secondary-subtle">
                                            <div class="d-inline-flex align-items-center justify-content-start w-100 mb-3">
                                                <i class="ti ti-mail me-2"></i>
                                                <p class="mb-0"><?php echo e(Auth::guard('admin')->user()->email); ?></p>
                                            </div>
                                            <div class="d-inline-flex align-items-center justify-content-start w-100 mb-3">
                                                <i class="ti ti-phone me-2"></i>
                                                <p class="mb-0"><?php echo e(Auth::guard('admin')->user()->phone); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-8 col-xxl-9">
                                <div class="card">
                                    <div class="card-header">
                                        <h5>Thông Tin Cá Nhân</h5>
                                    </div>
                                    <form class="card-body" method="POST" action="<?php echo e(route('update_profile')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="slugUser" value="<?php echo e(Auth::guard('admin')->user()->slugUser); ?>">
                                        <ul class="list-group list-group-flush">
                                            <li class="list-group-item px-0 pt-0">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <label class="form-label">Tên nhân sự</label>
                                                        <input type="text" class="form-control form-control"
                                                            placeholder="Tên nhân sự" fdprocessedid="w3ptog" name="fullName" id="slug"
                                                            value="<?php echo e(Auth::guard('admin')->user()->fullName); ?>">
                                                        <?php $__errorArgs = ['fullName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <small style="color: #f33923;"><?php echo e($message); ?></small>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label class="form-label">Phone nhân sự</label>
                                                        <input type="text" class="form-control form-control" placeholder="Phone nhân sự"
                                                            fdprocessedid="w3ptog" name="phone" value="<?php echo e(Auth::guard('admin')->user()->phone); ?>">
                                                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <small style="color: #f33923;"><?php echo e($message); ?></small>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </li>
                                            <li class="list-group-item px-0">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <label class="form-label">Ngày sinh</label>
                                                        <input class="form-control" type="date" name="birthday" value="<?php echo e(Auth::guard('admin')->user()->birthday); ?>"
                                                            id="demo-date-only">
                                                        <?php $__errorArgs = ['birthday'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <small style="color: #f33923;"><?php echo e($message); ?></small>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label class="form-label">Email nhân sự</label>
                                                        <input type="email" class="form-control form-control" placeholder="Email nhân sự"
                                                            fdprocessedid="w3ptog" name="email" disabled value="<?php echo e(Auth::guard('admin')->user()->email); ?>">
                                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <small style="color: #f33923;"><?php echo e($message); ?></small>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </li>
                                            <li class="list-group-item px-0">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <label class="form-label">Giới tính</label>
                                                        <div class="col-sm-12">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="radio" name="sex" value="0"
                                                                    id="customCheckinlhstate1" <?php echo e(Auth::guard('admin')->user()->sex == '0' ? 'checked' : ''); ?>

                                                                    data-gtm-form-interact-field-id="2">
                                                                <label class="form-check-label" for="customCheckinlhstate1"> Nam </label>
                                                            </div>
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="radio" name="sex" value="1"
                                                                    id="customCheckinlhstate2" <?php echo e(Auth::guard('admin')->user()->sex == '1' ? 'checked' : ''); ?>

                                                                    data-gtm-form-interact-field-id="1">
                                                                <label class="form-check-label" for="customCheckinlhstate2"> Nữ </label>
                                                            </div>
                                                        </div>
                                                        <?php $__errorArgs = ['sex'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <small style="color: #f33923;"><?php echo e($message); ?></small>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </li>
                                            <li class="list-group-item px-0 pb-0">
                                                <div class="col-12">
                                                    <button style="vertical-align: baseline;" class="btn btn-primary"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Cập nhật hồ sơ</font></font></button>
                                                </div>
                                            </li>
                                        </ul>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- [ Main Content ] end -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('view_js'); ?>
    <?php echo $__env->make('FEadmin.Layout.Fooder.js_fooder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('FEadmin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web_for_group\app-group\resources\views/FEadmin/Pages/Profile/index.blade.php ENDPATH**/ ?>