<?php
    use Carbon\Carbon;
?>
<?php $__env->startSection('css_view'); ?>
    <?php echo $__env->make('FEadmin.Layout.Head.css_tableButton_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('FEadmin.Layout.Head.js_tableButton_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php
    $typeHTML = [
        0 => ['name' => 'Thuê', 'color' => 'bg-pink-900'],
        1 => ['name' => 'Mua', 'color' => 'bg-purple-900'],
    ];

    $statusHTML = [
        0 => ['name' => 'Chưa Hỗ Trợ', 'color' => 'bg-pink-800'],
        1 => ['name' => 'Đã Hỗ Trợ', 'color' => 'bg-green-700'],
    ];

    $statusHTML_Buiding = [
        0 => ['name' => 'Chưa Lên Hợp Đồng', 'color' => '#e5c0c0'],
        1 => ['name' => 'Đã Lên Hợp Đồng', 'color' => '#c0e5d9'],
    ];

?>
<?php $__env->startSection('view'); ?>
    <div class="pc-content">
        <!-- [ breadcrumb ] start -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Trang Chủ</a></li>
                            <li class="breadcrumb-item"><a href="javascript: void(0)">Kinh Doanh</a></li>
                            <li class="breadcrumb-item"><a href="javascript: void(0)">Hỗ Trợ</a></li>
                            <li class="breadcrumb-item" aria-current="page">Danh Sách</li>
                        </ul>
                    </div>
                    <div class="col-md-12">
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- [ breadcrumb ] end -->
        <!-- [ Main Content ] start -->
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header" style="display: flex; align-items: center;justify-content: space-between;">
                        <div>
                            <h5>Danh Sách Hỗ Trợ</h5>
                        </div>
                        <div>
                            <a href="<?php echo e(route('view_create_cart')); ?>" class="btn btn-success">Tạo Mới</a>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="dt-responsive table-responsive">
                            <table id="cbtn-selectors" class="table table-striped table-bordered nowrap">
                                <thead>
                                    <tr>
                                        <th>stt</th>
                                        <th>Hợp Đồng</th>
                                        <th>Tên Khách</th>
                                        <th>Phone</th>
                                        <th>Email</th>
                                        <th>Tên Nhóm</th>
                                        <th>Giá Thuê</th>
                                        <th>Giá Bán</th>
                                        <th>Nhu Cầu</th>
                                        <th>Ngày Gửi</th>
                                        <th>Trạng thái</th>
                                        <th>Note</th>
                                        <th>Chức năng</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $type = $typeHTML[$value->status_type] ?? [
                                                'name' => 'Không Xác Định',
                                                'color' => '#000000',
                                            ];
                                            $typeName = $type['name'];
                                            $typeColor = $type['color'];
                                        ?>
                                        <?php
                                            $type = $statusHTML_Buiding[$value->check_buiding] ?? [
                                                'name' => 'Không Xác Định',
                                                'color' => '#000000',
                                            ];
                                            $typeNameBuiding = $type['name'];
                                            $typeColorBuiding = $type['color'];
                                        ?>
                                        <?php
                                            $status_color = $statusHTML[$value->status] ?? [
                                                'name' => 'Không Xác Định',
                                                'color' => '#000000',
                                            ];
                                            $status_name = $status_color['name'];
                                            $status_back = $status_color['color'];
                                        ?>
                                        <tr style="background: <?php echo e($typeColorBuiding); ?>">
                                            <td><?php echo e($key + 1); ?></td>
                                            <td><?php echo e($typeNameBuiding); ?></td>
                                            <td><a href="<?php echo e($value->linkFacebook); ?>"
                                                    target="_blank"><?php echo e($value->name_account); ?></a></td>
                                            <td><?php echo e($value->phone); ?></td>
                                            <td><?php echo e($value->email); ?></td>
                                            <td><?php echo e($value->nameGroup); ?></td>
                                            <td><?php echo e(number_format($value->rent_cost, 0, ',', '.')); ?></td>
                                            <td><?php echo e(number_format($value->price, 0, ',', '.')); ?></td>
                                            <td><span
                                                    class="badge rounded-pill <?php echo e($typeColor); ?>"><?php echo e($typeName); ?></span>
                                            </td>
                                            <td>
                                                <?php echo e(Carbon::parse($value->timeCreate)->locale('vi')->isoFormat('Do [tháng] M [năm] YYYY, H:mm:ss A')); ?>

                                            </td>
                                            <td><span
                                                    class="badge rounded-pill <?php echo e($status_back); ?>"><?php echo e($status_name); ?></span>
                                            </td>
                                            <td style="white-space: normal;">
                                                <div style="max-width: 300px; word-wrap: break-word;">
                                                    <span><?php echo e($value->note); ?> </span>
                                                </div>
                                            </td>
                                            <td class="action">
                                                <div class="btn-group-dropdown">
                                                    <button
                                                        class="btn btn-outline-secondary dropdown-toggle btn-sm mg-button-left"
                                                        type="button" data-bs-toggle="dropdown" aria-haspopup="true"
                                                        aria-expanded="false">Lựa chọn</button>
                                                    <div class="dropdown-menu">
                                                        <?php if($value->check_buiding == 0): ?>
                                                            <a class="dropdown-item"
                                                                href="<?php echo e(route('index_buiding', $value->id)); ?>"><span
                                                                    style="display: flex; justify-content: flex-start; color: #352ca8;"><i
                                                                        class="fas fa-save"></i> Tạo Hợp Đồng</span></a>
                                                        <?php else: ?>
                                                            <a class="dropdown-item"
                                                                href="<?php echo e(route('view_detail_buiding', $value->id)); ?>"><span
                                                                    style="display: flex; justify-content: flex-start; color: #352ca8;"><i
                                                                        class="ti ti-eye me-1"></i> Xem Hợp Đồng</span></a>
                                                        <?php endif; ?>

                                                        <a class="dropdown-item"
                                                            href="<?php echo e(route('view_update_cart', $value->id)); ?>"><span
                                                                style="display: flex; justify-content: flex-start; color: #2ca87f;"><i
                                                                    class="ti ti-pencil me-1"></i> Note & Trạng
                                                                Thái</span></a>
                                                        <a class="dropdown-item"
                                                            href="<?php echo e(route('delete_cart', $value->id)); ?>" title="Delete"
                                                            onclick="return confirm('Bạn Có Chắc Muốn Xóa Khách <?php echo e($value->name_account); ?> Không?')">
                                                            <span
                                                                style="display: flex; justify-content: flex-start; color: #dc2626;"><i
                                                                    class="ti ti-trash me-1"></i> Xóa</span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td>stt</td>
                                        <td>Tên Khách</td>
                                        <td>Phone</td>
                                        <td>Email</td>
                                        <td>Tên Nhóm</td>
                                        <td>Giá Thuê</td>
                                        <td>Giá Bán</td>
                                        <td>Nhu Cầu</td>
                                        <td>Ngày tạo</td>
                                        <td>Trạng thái</td>
                                        <td>Note</td>
                                        <td>Chức năng</td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('view_js'); ?>
    <?php echo $__env->make('FEadmin.Layout.Fooder.js_fooder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('FEadmin.Layout.Fooder.js_tableButton_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('FEadmin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web_for_group\app-group\resources\views/FEadmin/Pages/Cart/view_list.blade.php ENDPATH**/ ?>