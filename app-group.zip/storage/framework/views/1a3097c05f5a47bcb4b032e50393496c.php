<?php $__env->startSection('view'); ?>
<?php
$typeHTML = [
0 => ['name' => 'Riêng Tư', 'color' => 'bg-danger bg-gradient'],
1 => ['name' => 'Công Khai', 'color' => 'bg-success bg-gradient'],
];

$statusHTML = [
0 => ['name' => 'Hiển Thị', 'color' => 'bg-cyan-900'],
1 => ['name' => 'Lưu trữ', 'color' => 'bg-gray-800'],
];

$statusColor_HTML = [
0 => ['color' => '#00874e87', 'background' => '#00874e87'],
1 => ['color' => '#f1f708', 'background' => '#dbf70854'],
2 => ['color' => '#ff0000', 'background' => '#e7000069'],
];

$type = $typeHTML[$obj->type] ?? [
'name' => 'Không Xác Định',
'color' => '#000000',
];
$typeName = $type['name'];
$typeColor = $type['color'];
$address = '';

// Kiểm tra và thêm thông tin thành phố
if (isset($obj->province)) {
$address .= $obj->province;
}

// Kiểm tra và thêm thông tin quận huyện
if (isset($obj->district)) {
if ($address !== '') {
$address .= ' - ';
}
$address .= $obj->district;
}

// Kiểm tra và thêm thông tin phường xã
if (isset($obj->wards)) {
if ($address !== '') {
$address .= ' - ';
}
$address .= $obj->wards;
}
?>
<!-- Start -->
<section class="bg-half d-table w-100" style="min-height: 1000px;">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-4 col-md-12" id="history">
                <div class="card bg-white p-4 rounded shadow sticky-bar">
                    <!-- RECENT POST -->
                    <div class="mt-4 pt-2">
                        <h6 class="pt-2 pb-2 bg-light rounded text-center" style="background-color: #ff0018 !important; color: white;">Nhóm Đã Xem</h6>
                        <div class="mt-4">
                            <?php $__currentLoopData = $historyList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $valueHistory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($valueHistory['slugGroup'] != $obj->slugGroup): ?>
                            <div class="blog blog-primary d-flex align-items-center" style="padding: 0px 0px 15px 0px;">
                                <div class="flex-1 ms-3">
                                    <a href="<?php echo e(route('view_detail_group', $valueHistory['slugGroup'])); ?>"
                                        class="d-block title text-dark fw-medium"><?php echo e($valueHistory['nameGroup']); ?></a>
                                    <span class="text-muted small"><?php echo e($obj->account_group); ?> thành viên</span>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <!-- RECENT POST -->
                </div>
            </div>
            <div class="col-lg-8 col-md-12">
                <div class="sidebar border-0">
                    <h5 class="mb-0">Thông Tin Chi Tiết Nhóm Đang Xem</h5>
                    <div class="mt-4">
                        <img src="<?php echo e($obj->image); ?>" class="avatar shadow bg-white" alt="" style="width: 100%;">
                    </div>
                    <h4 class="title mb-3 mt-3"><a href="<?php echo e($obj->linkGroup); ?>" target="_blank"
                            style="color: rgb(253 13 13); font-weight: 700;" class="hover-h4"><?php echo e($obj->nameGroup); ?></a></h4>
                    <ul class="list-unstyled mb-0 mt-4">
                        <li class="list-inline-item px-3 py-2 shadow rounded text-start m-1 bg-white">
                            <div class="d-flex widget align-items-center">
                                <i data-feather="monitor" class="fea icon-ex-md me-3"></i>
                                <div class="flex-1">
                                    <h6 class="widget-title mb-0">Loại Nhóm</h6>
                                    <small class="text-primary mb-0"><?php echo e($typeName); ?></small>
                                </div>
                            </div>
                        </li>

                        <li class="list-inline-item px-3 py-2 shadow rounded text-start m-1 bg-white">
                            <div class="d-flex widget align-items-center">
                                <i data-feather="user-check" class="fea icon-ex-md me-3"></i>
                                <div class="flex-1">
                                    <h6 class="widget-title mb-0">Thành Viên</h6>
                                    <small class="text-primary mb-0"><?php echo e($obj->account_group); ?> thành viên</small>
                                </div>
                            </div>
                        </li>

                        <li class="list-inline-item px-3 py-2 shadow rounded text-start m-1 bg-white">
                            <div class="d-flex widget align-items-center">
                                <i data-feather="map-pin" class="fea icon-ex-md me-3"></i>
                                <div class="flex-1">
                                    <h6 class="widget-title mb-0"><?php echo e($obj->objCategory->name); ?></h6>
                                    <small class="text-primary mb-0"><?php echo e($address); ?></small>
                                </div>
                            </div>
                        </li>

                        <li class="list-inline-item px-3 py-2 shadow rounded text-start m-1 bg-white">
                            <div class="d-flex widget align-items-center">
                                <i data-feather="briefcase" class="fea icon-ex-md me-3"></i>
                                <div class="flex-1">
                                    <h6 class="widget-title mb-0">Lượng Thành Viên / Tuần</h6>
                                    <small class="text-primary mb-0">+<?php echo e($obj->account_group_week); ?> thành viên /
                                        tuần</small>
                                </div>
                            </div>
                        </li>

                        <li class="list-inline-item px-3 py-2 shadow rounded text-start m-1 bg-white">
                            <div class="d-flex widget align-items-center">
                                <i data-feather="book" class="fea icon-ex-md me-3"></i>
                                <div class="flex-1">
                                    <h6 class="widget-title mb-0">Lượng Bài Viết / Tuần</h6>
                                    <small class="text-primary mb-0">+<?php echo e($obj->account_group_blog); ?> bài / tuần</small>
                                </div>
                            </div>
                        </li>

                        <li class="list-inline-item px-3 py-2 shadow rounded text-start m-1 bg-white">
                            <div class="d-flex widget align-items-center">
                                <i data-feather="key" class="fea icon-ex-md me-3"></i>
                                <div class="flex-1">
                                    <h6 class="widget-title mb-0">Mã Nhóm</h6>
                                    <small class="text-primary mb-0"><?php echo e($obj->code); ?></small>
                                </div>
                            </div>
                        </li>

                        <li class="list-inline-item px-3 py-2 shadow rounded text-start m-1 bg-white">
                            <div class="d-flex widget align-items-center">
                                <i data-feather="dollar-sign" class="fea icon-ex-md me-3"></i>
                                <div class="flex-1">
                                    <h6 class="widget-title mb-0">Giá Thuê</h6>
                                    <small class="text-primary mb-0"><?php echo e(number_format($obj->rent_cost, 0, ',', '.')); ?>

                                        vnđ / tháng</small>
                                </div>
                            </div>
                        </li>

                        <li class="list-inline-item px-3 py-2 shadow rounded text-start m-1 bg-white">
                            <div class="d-flex widget align-items-center">
                                <i data-feather="dollar-sign" class="fea icon-ex-md me-3"></i>
                                <div class="flex-1">
                                    <h6 class="widget-title mb-0">Giá Bán</h6>
                                    <small class="text-primary mb-0"><?php echo e(number_format($obj->price, 0, ',', '.')); ?>

                                        vnđ</small>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>

                <div class="mt-4">
                    <h5>Mô Tả: </h5>
                    <?php if(empty($obj->detail_group)): ?>
                    <p class="text-muted">Chưa có thông tin miêu tả.</p>
                    <?php else: ?>
                    <div>
                        <?php echo $obj->detail_group; ?>

                    </div>
                    <?php endif; ?>

                    
                </div>
                <div class="mt-4">
                    <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal"
                        data-bs-target="#exampleModalCenter">Đăng Ký <i class="mdi mdi-send"></i></button>
                </div>
            </div>
            <!--end col-->
        </div>
    </div>
    <!--end container-->

    <div class="container mt-50 mt-60">
        <div class="row justify-content-center mb-0 pb-2">
            <div class="col-12">
                <div class="section-title text-center">
                    <h4 class="title mb-4">Nhóm Liên Quan</h4>
                </div>
            </div>
            <!--end col-->
        </div>
        <!--end row-->

        <div class="row">
            <?php $__currentLoopData = $listDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $type = $typeHTML[$value->type] ?? [
            'name' => 'Không Xác Định',
            'color' => '#000000',
            ];
            $typeName = $type['name'];
            $typeColor = $type['color'];
            $address = '';

            // Kiểm tra và thêm thông tin thành phố
            if (isset($value->province)) {
            $address .= $value->province;
            }

            // Kiểm tra và thêm thông tin quận huyện
            if (isset($value->district)) {
            if ($address !== '') {
            $address .= ' - ';
            }
            $address .= $value->district;
            }

            // Kiểm tra và thêm thông tin phường xã
            if (isset($value->wards)) {
            if ($address !== '') {
            $address .= ' - ';
            }
            $address .= $value->wards;
            }
            ?>
            <div class="col-xl-12 col-lg-4 col-md-6 col-sm-6 col-12">
                <div class="job-post job-post-list rounded shadow p-3 mb-4 d-xl-flex align-items-center justify-content-between position-relative"
                    style="padding: 8px 10px !important;">
                    <div class="d-flex align-items-center w-350px">
                        <div>
                            <div class="truncate-mobile">
                                <a href="<?php echo e($value->linkGroup); ?>" target="_blank" style="font-size: 15px !important;"
                                    class="h5 title text-dark"><?php echo e($value->nameGroup); ?></a>

                            </div>
                            <span class="d-flex fw-medium mt-md-2" font-size: 12px;><?php echo e($value->account_group); ?> Thành
                                Viên</span>
                        </div>
                    </div>

                    <div class="d-flex align-items-center justify-content-between d-xl-block mt-3 mt-md-0 w-120px">
                        <span class="badge rounded-pill <?php echo e($typeColor); ?>"><?php echo e($typeName); ?></span>
                        <span class="text-muted d-flex align-items-center fw-medium mt-lg-2"><i
                                class="fea icon-sm me-1 align-middle fas fa-map-signs"></i><?php echo e($value->category); ?></span>
                    </div>

                    <div class="d-blog align-items-center justify-content-between d-xl-block mt-3 mt-md-0 w-280px">
                        <span class="text-muted d-flex align-items-center fw-medium mt-md-2">
                            Giá Thuê: <?php echo e(number_format($value->rent_cost, 0, ',', '.')); ?> vnđ /
                            tháng</span>
                        <span class="text-muted d-flex align-items-center fw-medium mt-md-2 mb-10px">
                            Giá Bán: <?php echo e(number_format($value->price, 0, ',', '.')); ?> vnđ</span>
                    </div>

                    <div
                        class="d-blog align-items-center justify-content-between d-xl-block mt-2 mt-md-0 w-350px truncate">
                        <span class="text-muted d-flex align-items-center mt-md-2"><i data-feather="map-pin"
                                class="fea icon-sm me-1 align-middle"></i><?php echo e($value->objCategory->name); ?></span>
                        <span class="d-flex fw-medium mt-md-2 mb-10px mb-md-2" style="font-size: 11.5px;"><?php echo e($address); ?></span>
                    </div>

                    <div class="mt-3 mt-md-0">
                        <a href="<?php echo e(route('view_detail_group', $value->slugGroup)); ?>"
                            class="btn btn-sm btn-primary w-full">Đăng Ký</a>
                    </div>
                </div>
            </div>
            <!--end col-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!--end row-->
    </div>
    <!--end container-->
</section>

<section id="exampleModalCenter" class="modal fade" tabindex="-1" role="dialog"
    aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <?php echo csrf_field(); ?>
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Thông Tin Liên Hệ</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body row">
                <div id="accordion">

                    <div class="card">
                        <div class="card-header">
                            <a class="btn" data-bs-toggle="collapse" href="#collapseOne">
                                Thông Tin Liên Hệ
                            </a>
                        </div>
                        <div id="collapseOne" class="collapse show" data-bs-parent="#accordion">
                            <div class="card-body">
                                <p style="font-size: 15px;"><span style="color: #f2277e;;">Mọi Khó Khăn Hãy
                                        Liên Hệ Qua Zalo Qua Số <span
                                            style="font-weight: 600; text-decoration: underline;">0888.999.857</span>
                                        Để Được Hỗ
                                        Trợ!</span></p>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-header">
                            <a class="collapsed btn" data-bs-toggle="collapse" href="#collapseTwo">
                                Thông Tin Thanh Toán
                            </a>
                        </div>
                        <div id="collapseTwo" class="collapse" data-bs-parent="#accordion">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-12 col-lg-6">
                                        <img style="width: 100%;"
                                            src="https://chiasekhoahoc.com.vn/asset/img/herobanner/qr.png"
                                            class="rounded" alt="Cinque Terre">
                                    </div>
                                    <div class="col-12 col-lg-6" style="padding: 30px 10px 0px 10px;">
                                        <h4>Thông Tin Người Nhận &amp; Nội Dung Chuyền Khoản</h4>
                                        <p style="font-size: 15px;">Chủ Tài Khoản: <span
                                                style="font-size: 18px; color: black; font-weight: 600;">Lo Thi
                                                Dung</span></p>
                                        <p style="font-size: 15px;">Số Tài Khoản: <span
                                                style="font-size: 18px; color: black; font-weight: 600;">1903 9284 8630
                                                16</span></p>
                                        <p style="font-size: 15px;">Nội Dung: <span
                                                style="font-size: 14px; color: #f2277e; font-weight: 600;"> Thue "Mã
                                                Nhóm"</span> hoặc <span
                                                style="font-size: 14px; color: #f2277e; font-weight: 600;"> Mua "Mã
                                                Nhóm"</span>
                                        </p>

                                        <p style="font-size: 15px;">Ghi Chú: <span style="color: #f2277e;;">Mọi Khó
                                                Khăn Hãy Liên Hệ Qua Zalo Qua Số <span
                                                    style="font-weight: 600; text-decoration: underline;">0888.999.857</span>
                                                Để Được Hỗ
                                                Trợ!</span></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Thoát</button>
            </div>
        </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('view_js'); ?>
<script>
    // Xác định modal
        var myModal = new bootstrap.Modal(document.getElementById('exampleModalCenter'));

        // Kiểm tra nếu có lỗi và modal chưa được hiển thị, thì hiển thị modal
        window.onload = function() {
            <?php if($errors->any() && !session('modalShown')): ?>
                myModal.show();
            <?php endif; ?>
        };
</script>
<!-- End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('FEuser.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web_for_group\app-group\resources\views/FEuser/Pages/Detail/group_detail.blade.php ENDPATH**/ ?>