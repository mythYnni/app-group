<!-- Bootstrap core CSS -->
<link href="<?php echo e(url('assets')); ?>/user/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
<link href="<?php echo e(url('assets')); ?>/user/css/choices.min.css" rel="stylesheet" />
<link href="<?php echo e(url('assets')); ?>/user/css/materialdesignicons.min.css" rel="stylesheet" type="text/css" />
<!-- Custom  Css -->
<link href="<?php echo e(url('assets')); ?>/user/css/style.min.css" rel="stylesheet" type="text/css" id="theme-opt" /><?php /**PATH D:\web_for_group\app-group\resources\views/FEuser/Layout/Header/Css_Header.blade.php ENDPATH**/ ?>