<!DOCTYPE html>
<html lang="en">
<!-- [Head] start -->

<!-- Mirrored from ableproadmin.com/dashboard/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 01 Apr 2024 07:24:56 GMT -->
<head>
    <title>Quản Trị - DPC Marketing</title>
    <!-- [Meta] -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <?php echo $__env->make('FEadmin.Layout.Head.meta_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- [Favicon] icon -->
    <link rel="icon" href="<?php echo e(url('assets')); ?>/images/logo.png" type="image/x-icon">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <?php echo $__env->yieldContent('css_view'); ?>
</head>
<!-- [Head] end -->
<!-- [Body] Start -->
<body data-pc-preset="preset-1" data-pc-sidebar-caption="true" data-pc-direction="ltr" data-pc-theme_contrast data-pc-theme="light">
    <!-- [ Pre-loader ] start -->
    <?php echo $__env->make('FEadmin.Layout.Body.pre_loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- [ Pre-loader ] End -->
    <!-- [ Sidebar Menu ] start -->
    <?php echo $__env->make('FEadmin.Layout.Body.sidebar_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- [ Sidebar Menu ] end --> 
    <!-- [ Header Topbar ] start -->
    <?php echo $__env->make('FEadmin.Layout.Body.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- [ Header ] end -->
    <!-- [ Main Content ] start -->
    <div class="pc-container">
        <?php echo $__env->yieldContent('view'); ?>
    </div>
    <?php echo $__env->make('FEadmin.Layout.Body.setting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->yieldContent('view_js'); ?>
    <!-- :: SUCCESS -->
    <?php echo $__env->make('FEadmin.Sweetalert.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- :: END SUCCESS -->
    <!-- :: ERROR -->
    <?php echo $__env->make('FEadmin.Sweetalert.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- :: END ERROR -->
</body>
<!-- [Body] end -->
</html>
<?php /**PATH D:\web_for_group\app-group\resources\views/FEadmin/master.blade.php ENDPATH**/ ?>