
<?php $__env->startSection('view'); ?>
    <?php
        $typeHTML = [
            0 => ['name' => 'Riêng Tư', 'color' => 'bg-danger bg-gradient'],
            1 => ['name' => 'Công Khai', 'color' => 'bg-success bg-gradient'],
        ];

        $statusHTML = [
            0 => ['name' => 'Hiển Thị', 'color' => 'bg-cyan-900'],
            1 => ['name' => 'Lưu trữ', 'color' => 'bg-gray-800'],
        ];

        $statusColor_HTML = [
            0 => ['color' => '#00874e87', 'background' => '#00874e87'],
            1 => ['color' => '#f1f708', 'background' => '#dbf70854'],
            2 => ['color' => '#ff0000', 'background' => '#e7000069'],
        ];

        $province = isset($filters['province']) ? $filters['province'] : "";
        $district = isset($filters['district']) ? $filters['district'] : "";
        $wards = isset($filters['wards']) ? $filters['wards'] : "";
        $category = isset($filters['category']) ? $filters['category'] : "";
        $search = isset($filters['search']) ? $filters['search'] : "";

    ?>
    <section class="section" style="min-height: 1000px;">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12">
                    <div class="title-heading text-center">
                        
                    </div>
                </div><!--end col-->
                <div class="col-12 mt-4">
                    <div class="features-absolute">
                        <div class="d-md-flex justify-content-between align-items-center bg-white shadow rounded p-4">
                            <form class="card-body text-start" method="get">
                                <div class="registration-form text-dark text-start">
                                    <div class="row g-lg-1" id="menuSearch">

                                    </div><!--end row-->
                                </div>
                            </form><!--end form-->
                        </div>
                    </div>
                </div><!--end col-->
            </div><!--end row-->
        </div><!--end container-->

        <div class="container">
            <div class="alert alert-success" style="padding: 0px; background: #ff0018; border-color: #ff0018;">
                <img loading="lazy" class="responsite-image-text" style="margin-left: 15px;"
                    src="<?php echo e(url('assets')); ?>/images/Minimalist_Blue_Green_Real_Estate_Company_Group_Logo-removebg-preview.png"
                    alt="grid">
            </div>
            <?php if(isset($filters['province']) && isset($filters['district']) && isset($filters['wards'])): ?>
                <div class="col-lg-12 col-md-12">
                    <div class="mb-4">
                        <div class="accordion mt-4 pt-2" id="buyingquestion">
                            <div class="accordion-item rounded">
                                <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button border-0 bg-light" type="button"
                                        data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true"
                                        aria-controls="collapseOne">
                                        <?php echo e($filters['province']); ?>

                                    </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse border-0 collapse show"
                                    aria-labelledby="headingOne" data-bs-parent="#buyingquestion">
                                    <div class="accordion-body text-muted">
                                        <div class="row g-2">
                                            <?php $__currentLoopData = $allByProvince; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $type = $typeHTML[$value->type] ?? [
                                                        'name' => 'Không Xác Định',
                                                        'color' => '#000000',
                                                    ];
                                                    $typeName = $type['name'];
                                                    $typeColor = $type['color'];
                                                    $address = '';

                                                    // Kiểm tra và thêm thông tin thành phố
                                                    if (isset($value->province)) {
                                                        $address .= $value->province;
                                                    }

                                                    // Kiểm tra và thêm thông tin quận huyện
                                                    if (isset($value->district)) {
                                                        if ($address !== '') {
                                                            $address .= ' - ';
                                                        }
                                                        $address .= $value->district;
                                                    }

                                                    // Kiểm tra và thêm thông tin phường xã
                                                    if (isset($value->wards)) {
                                                        if ($address !== '') {
                                                            $address .= ' - ';
                                                        }
                                                        $address .= $value->wards;
                                                    }
                                                ?>
                                                <div class="col-xl-12 col-lg-4 col-md-6 col-sm-6 col-12">
                                                    <div
                                                        class="job-post job-post-list rounded shadow p-3 d-xl-flex align-items-center justify-content-between position-relative">
                                                        <div class="d-flex align-items-center w-350px">
                                                            <div>
                                                                <div class="truncate-mobile">
                                                                    <a href="<?php echo e($value->linkGroup); ?>" target="_blank"
                                                                        class="h5 title text-dark"><?php echo e($value->nameGroup); ?></a>

                                                                </div>
                                                                <span
                                                                    class="d-flex fw-medium mt-md-2"><?php echo e($value->account_group); ?>

                                                                    Thành Viên</span>
                                                            </div>
                                                        </div>

                                                        <div
                                                            class="d-flex align-items-center justify-content-between d-xl-block mt-3 mt-md-0 w-120px">
                                                            <span
                                                                class="badge rounded-pill <?php echo e($typeColor); ?>"><?php echo e($typeName); ?></span>
                                                            <span
                                                                class="text-muted d-flex align-items-center fw-medium mt-lg-2"><i
                                                                    class="fea icon-sm me-1 align-middle fas fa-map-signs"></i><?php echo e($value->category); ?></span>
                                                        </div>

                                                        <div
                                                            class="d-blog align-items-center justify-content-between d-xl-block mt-3 mt-md-0 w-280px">
                                                            <span
                                                                class="text-muted d-flex align-items-center fw-medium mt-md-2">
                                                                Giá Thuê:
                                                                <?php echo e(number_format($value->rent_cost, 0, ',', '.')); ?>

                                                                vnđ / tháng</span>
                                                            <span
                                                                class="text-muted d-flex align-items-center fw-medium mt-md-2 mb-10px">
                                                                Giá Bán: <?php echo e(number_format($value->price, 0, ',', '.')); ?>

                                                                vnđ</span>
                                                        </div>

                                                        <div
                                                            class="d-blog align-items-center justify-content-between d-xl-block mt-2 mt-md-0 w-350px truncate">
                                                            <span class="text-muted d-flex align-items-center mt-md-2"><i
                                                                    data-feather="map-pin"
                                                                    class="fea icon-sm me-1 align-middle"></i><?php echo e($value->objCategory->name); ?></span>
                                                            <span class="d-flex fw-medium mt-md-2 mb-10px mb-md-2"
                                                                style="font-size: 11.5px;"><?php echo e($address); ?></span>
                                                        </div>

                                                        <div class="mt-3 mt-md-0">
                                                            <a href="<?php echo e(route('view_detail_group', $value->slugGroup)); ?>"
                                                                class="btn btn-sm btn-primary w-full">Đăng Ký</a>
                                                        </div>
                                                    </div>
                                                </div><!--end col-->
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div><!--end row-->
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item rounded mt-2">
                                <h2 class="accordion-header" id="headingTwo">
                                    <button class="accordion-button border-0 bg-light collapsed" type="button"
                                        data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false"
                                        aria-controls="collapseTwo">
                                        <?php echo e($filters['district']); ?>

                                    </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse border-0 collapse"
                                    aria-labelledby="headingTwo" data-bs-parent="#buyingquestion">
                                    <div class="accordion-body text-muted">
                                        <div class="row g-2">
                                            <?php $__currentLoopData = $allByProvinceAndDistrict; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $type = $typeHTML[$value->type] ?? [
                                                        'name' => 'Không Xác Định',
                                                        'color' => '#000000',
                                                    ];
                                                    $typeName = $type['name'];
                                                    $typeColor = $type['color'];
                                                    $address = '';

                                                    // Kiểm tra và thêm thông tin thành phố
                                                    if (isset($value->province)) {
                                                        $address .= $value->province;
                                                    }

                                                    // Kiểm tra và thêm thông tin quận huyện
                                                    if (isset($value->district)) {
                                                        if ($address !== '') {
                                                            $address .= ' - ';
                                                        }
                                                        $address .= $value->district;
                                                    }

                                                    // Kiểm tra và thêm thông tin phường xã
                                                    if (isset($value->wards)) {
                                                        if ($address !== '') {
                                                            $address .= ' - ';
                                                        }
                                                        $address .= $value->wards;
                                                    }
                                                ?>
                                                <div class="col-xl-12 col-lg-4 col-md-6 col-sm-6 col-12">
                                                    <div
                                                        class="job-post job-post-list rounded shadow p-3 d-xl-flex align-items-center justify-content-between position-relative">
                                                        <div class="d-flex align-items-center w-350px">
                                                            <div>
                                                                <div class="truncate-mobile">
                                                                    <a href="<?php echo e($value->linkGroup); ?>" target="_blank"
                                                                        class="h5 title text-dark"><?php echo e($value->nameGroup); ?></a>

                                                                </div>
                                                                <span
                                                                    class="d-flex fw-medium mt-md-2"><?php echo e($value->account_group); ?>

                                                                    Thành Viên</span>
                                                            </div>
                                                        </div>

                                                        <div
                                                            class="d-flex align-items-center justify-content-between d-xl-block mt-3 mt-md-0 w-120px">
                                                            <span
                                                                class="badge rounded-pill <?php echo e($typeColor); ?>"><?php echo e($typeName); ?></span>
                                                            <span
                                                                class="text-muted d-flex align-items-center fw-medium mt-lg-2"><i
                                                                    class="fea icon-sm me-1 align-middle fas fa-map-signs"></i><?php echo e($value->category); ?></span>
                                                        </div>

                                                        <div
                                                            class="d-blog align-items-center justify-content-between d-xl-block mt-3 mt-md-0 w-280px">
                                                            <span
                                                                class="text-muted d-flex align-items-center fw-medium mt-md-2">
                                                                Giá Thuê:
                                                                <?php echo e(number_format($value->rent_cost, 0, ',', '.')); ?>

                                                                vnđ / tháng</span>
                                                            <span
                                                                class="text-muted d-flex align-items-center fw-medium mt-md-2 mb-10px">
                                                                Giá Bán: <?php echo e(number_format($value->price, 0, ',', '.')); ?>

                                                                vnđ</span>
                                                        </div>

                                                        <div
                                                            class="d-blog align-items-center justify-content-between d-xl-block mt-2 mt-md-0 w-350px truncate">
                                                            <span class="text-muted d-flex align-items-center mt-md-2"><i
                                                                    data-feather="map-pin"
                                                                    class="fea icon-sm me-1 align-middle"></i><?php echo e($value->objCategory->name); ?></span>
                                                            <span class="d-flex fw-medium mt-md-2 mb-10px mb-md-2"
                                                                style="font-size: 11.5px;"><?php echo e($address); ?></span>
                                                        </div>

                                                        <div class="mt-3 mt-md-0">
                                                            <a href="<?php echo e(route('view_detail_group', $value->slugGroup)); ?>"
                                                                class="btn btn-sm btn-primary w-full">Đăng Ký</a>
                                                        </div>
                                                    </div>
                                                </div><!--end col-->
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div><!--end row-->
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item rounded mt-2">
                                <h2 class="accordion-header" id="headingThree">
                                    <button class="accordion-button border-0 bg-light collapsed" type="button"
                                        data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false"
                                        aria-controls="collapseThree">
                                        <?php echo e($filters['wards']); ?>

                                    </button>
                                </h2>
                                <div id="collapseThree" class="accordion-collapse border-0 collapse"
                                    aria-labelledby="headingThree" data-bs-parent="#buyingquestion">
                                    <div class="accordion-body text-muted">
                                        <div class="row g-2">
                                            <?php $__currentLoopData = $searchResult; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $type = $typeHTML[$value->type] ?? [
                                                        'name' => 'Không Xác Định',
                                                        'color' => '#000000',
                                                    ];
                                                    $typeName = $type['name'];
                                                    $typeColor = $type['color'];
                                                    $address = '';

                                                    // Kiểm tra và thêm thông tin thành phố
                                                    if (isset($value->province)) {
                                                        $address .= $value->province;
                                                    }

                                                    // Kiểm tra và thêm thông tin quận huyện
                                                    if (isset($value->district)) {
                                                        if ($address !== '') {
                                                            $address .= ' - ';
                                                        }
                                                        $address .= $value->district;
                                                    }

                                                    // Kiểm tra và thêm thông tin phường xã
                                                    if (isset($value->wards)) {
                                                        if ($address !== '') {
                                                            $address .= ' - ';
                                                        }
                                                        $address .= $value->wards;
                                                    }
                                                ?>
                                                <div class="col-xl-12 col-lg-4 col-md-6 col-sm-6 col-12">
                                                    <div
                                                        class="job-post job-post-list rounded shadow p-3 d-xl-flex align-items-center justify-content-between position-relative">
                                                        <div class="d-flex align-items-center w-350px">
                                                            <div>
                                                                <div class="truncate-mobile">
                                                                    <a href="<?php echo e($value->linkGroup); ?>" target="_blank"
                                                                        class="h5 title text-dark"><?php echo e($value->nameGroup); ?></a>

                                                                </div>
                                                                <span
                                                                    class="d-flex fw-medium mt-md-2"><?php echo e($value->account_group); ?>

                                                                    Thành Viên</span>
                                                            </div>
                                                        </div>

                                                        <div
                                                            class="d-flex align-items-center justify-content-between d-xl-block mt-3 mt-md-0 w-120px">
                                                            <span
                                                                class="badge rounded-pill <?php echo e($typeColor); ?>"><?php echo e($typeName); ?></span>
                                                            <span
                                                                class="text-muted d-flex align-items-center fw-medium mt-lg-2"><i
                                                                    class="fea icon-sm me-1 align-middle fas fa-map-signs"></i><?php echo e($value->category); ?></span>
                                                        </div>

                                                        <div
                                                            class="d-blog align-items-center justify-content-between d-xl-block mt-3 mt-md-0 w-280px">
                                                            <span
                                                                class="text-muted d-flex align-items-center fw-medium mt-md-2">
                                                                Giá Thuê:
                                                                <?php echo e(number_format($value->rent_cost, 0, ',', '.')); ?>

                                                                vnđ / tháng</span>
                                                            <span
                                                                class="text-muted d-flex align-items-center fw-medium mt-md-2 mb-10px">
                                                                Giá Bán: <?php echo e(number_format($value->price, 0, ',', '.')); ?>

                                                                vnđ</span>
                                                        </div>

                                                        <div
                                                            class="d-blog align-items-center justify-content-between d-xl-block mt-2 mt-md-0 w-350px truncate">
                                                            <span class="text-muted d-flex align-items-center mt-md-2"><i
                                                                    data-feather="map-pin"
                                                                    class="fea icon-sm me-1 align-middle"></i><?php echo e($value->objCategory->name); ?></span>
                                                            <span class="d-flex fw-medium mt-md-2 mb-10px mb-md-2"
                                                                style="font-size: 11.5px;"><?php echo e($address); ?></span>
                                                        </div>

                                                        <div class="mt-3 mt-md-0">
                                                            <a href="<?php echo e(route('view_detail_group', $value->slugGroup)); ?>"
                                                                class="btn btn-sm btn-primary w-full">Đăng Ký</a>
                                                        </div>
                                                    </div>
                                                </div><!--end col-->
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div><!--end row-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php elseif(isset($filters['province']) && isset($filters['district']) && !isset($filters['wards'])): ?>
                <div class="col-lg-12 col-md-12">
                    <div class="mb-4">
                        <div class="accordion mt-4 pt-2" id="buyingquestion">
                            <div class="accordion-item rounded">
                                <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button border-0 bg-light" type="button"
                                        data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true"
                                        aria-controls="collapseOne">
                                        <?php echo e($filters['province']); ?>

                                    </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse border-0 collapse show"
                                    aria-labelledby="headingOne" data-bs-parent="#buyingquestion">
                                    <div class="accordion-body text-muted">
                                        <div class="row g-2">
                                            <?php $__currentLoopData = $allByProvince; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $type = $typeHTML[$value->type] ?? [
                                                        'name' => 'Không Xác Định',
                                                        'color' => '#000000',
                                                    ];
                                                    $typeName = $type['name'];
                                                    $typeColor = $type['color'];
                                                    $address = '';

                                                    // Kiểm tra và thêm thông tin thành phố
                                                    if (isset($value->province)) {
                                                        $address .= $value->province;
                                                    }

                                                    // Kiểm tra và thêm thông tin quận huyện
                                                    if (isset($value->district)) {
                                                        if ($address !== '') {
                                                            $address .= ' - ';
                                                        }
                                                        $address .= $value->district;
                                                    }

                                                    // Kiểm tra và thêm thông tin phường xã
                                                    if (isset($value->wards)) {
                                                        if ($address !== '') {
                                                            $address .= ' - ';
                                                        }
                                                        $address .= $value->wards;
                                                    }
                                                ?>
                                                <div class="col-xl-12 col-lg-4 col-md-6 col-sm-6 col-12">
                                                    <div
                                                        class="job-post job-post-list rounded shadow p-3 d-xl-flex align-items-center justify-content-between position-relative">
                                                        <div class="d-flex align-items-center w-350px">
                                                            <div>
                                                                <div class="truncate-mobile">
                                                                    <a href="<?php echo e($value->linkGroup); ?>" target="_blank"
                                                                        class="h5 title text-dark"><?php echo e($value->nameGroup); ?></a>

                                                                </div>
                                                                <span
                                                                    class="d-flex fw-medium mt-md-2"><?php echo e($value->account_group); ?>

                                                                    Thành Viên</span>
                                                            </div>
                                                        </div>

                                                        <div
                                                            class="d-flex align-items-center justify-content-between d-xl-block mt-3 mt-md-0 w-120px">
                                                            <span
                                                                class="badge rounded-pill <?php echo e($typeColor); ?>"><?php echo e($typeName); ?></span>
                                                            <span
                                                                class="text-muted d-flex align-items-center fw-medium mt-lg-2"><i
                                                                    class="fea icon-sm me-1 align-middle fas fa-map-signs"></i><?php echo e($value->category); ?></span>
                                                        </div>

                                                        <div
                                                            class="d-blog align-items-center justify-content-between d-xl-block mt-3 mt-md-0 w-280px">
                                                            <span
                                                                class="text-muted d-flex align-items-center fw-medium mt-md-2">
                                                                Giá Thuê:
                                                                <?php echo e(number_format($value->rent_cost, 0, ',', '.')); ?>

                                                                vnđ / tháng</span>
                                                            <span
                                                                class="text-muted d-flex align-items-center fw-medium mt-md-2 mb-10px">
                                                                Giá Bán: <?php echo e(number_format($value->price, 0, ',', '.')); ?>

                                                                vnđ</span>
                                                        </div>

                                                        <div
                                                            class="d-blog align-items-center justify-content-between d-xl-block mt-2 mt-md-0 w-350px truncate">
                                                            <span class="text-muted d-flex align-items-center mt-md-2"><i
                                                                    data-feather="map-pin"
                                                                    class="fea icon-sm me-1 align-middle"></i><?php echo e($value->objCategory->name); ?></span>
                                                            <span class="d-flex fw-medium mt-md-2 mb-10px mb-md-2"
                                                                style="font-size: 11.5px;"><?php echo e($address); ?></span>
                                                        </div>

                                                        <div class="mt-3 mt-md-0">
                                                            <a href="<?php echo e(route('view_detail_group', $value->slugGroup)); ?>"
                                                                class="btn btn-sm btn-primary w-full">Đăng Ký</a>
                                                        </div>
                                                    </div>
                                                </div><!--end col-->
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div><!--end row-->
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item rounded mt-2">
                                <h2 class="accordion-header" id="headingTwo">
                                    <button class="accordion-button border-0 bg-light collapsed" type="button"
                                        data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false"
                                        aria-controls="collapseTwo">
                                        <?php echo e($filters['district']); ?>

                                    </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse border-0 collapse"
                                    aria-labelledby="headingTwo" data-bs-parent="#buyingquestion">
                                    <div class="accordion-body text-muted">
                                        <div class="row g-2">
                                            <?php $__currentLoopData = $searchResult; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $type = $typeHTML[$value->type] ?? [
                                                        'name' => 'Không Xác Định',
                                                        'color' => '#000000',
                                                    ];
                                                    $typeName = $type['name'];
                                                    $typeColor = $type['color'];
                                                    $address = '';

                                                    // Kiểm tra và thêm thông tin thành phố
                                                    if (isset($value->province)) {
                                                        $address .= $value->province;
                                                    }

                                                    // Kiểm tra và thêm thông tin quận huyện
                                                    if (isset($value->district)) {
                                                        if ($address !== '') {
                                                            $address .= ' - ';
                                                        }
                                                        $address .= $value->district;
                                                    }

                                                    // Kiểm tra và thêm thông tin phường xã
                                                    if (isset($value->wards)) {
                                                        if ($address !== '') {
                                                            $address .= ' - ';
                                                        }
                                                        $address .= $value->wards;
                                                    }
                                                ?>
                                                <div class="col-xl-12 col-lg-4 col-md-6 col-sm-6 col-12">
                                                    <div
                                                        class="job-post job-post-list rounded shadow p-3 d-xl-flex align-items-center justify-content-between position-relative">
                                                        <div class="d-flex align-items-center w-350px">
                                                            <div>
                                                                <div class="truncate-mobile">
                                                                    <a href="<?php echo e($value->linkGroup); ?>" target="_blank"
                                                                        class="h5 title text-dark"><?php echo e($value->nameGroup); ?></a>

                                                                </div>
                                                                <span
                                                                    class="d-flex fw-medium mt-md-2"><?php echo e($value->account_group); ?>

                                                                    Thành Viên</span>
                                                            </div>
                                                        </div>

                                                        <div
                                                            class="d-flex align-items-center justify-content-between d-xl-block mt-3 mt-md-0 w-120px">
                                                            <span
                                                                class="badge rounded-pill <?php echo e($typeColor); ?>"><?php echo e($typeName); ?></span>
                                                            <span
                                                                class="text-muted d-flex align-items-center fw-medium mt-lg-2"><i
                                                                    class="fea icon-sm me-1 align-middle fas fa-map-signs"></i><?php echo e($value->category); ?></span>
                                                        </div>

                                                        <div
                                                            class="d-blog align-items-center justify-content-between d-xl-block mt-3 mt-md-0 w-280px">
                                                            <span
                                                                class="text-muted d-flex align-items-center fw-medium mt-md-2">
                                                                Giá Thuê:
                                                                <?php echo e(number_format($value->rent_cost, 0, ',', '.')); ?>

                                                                vnđ / tháng</span>
                                                            <span
                                                                class="text-muted d-flex align-items-center fw-medium mt-md-2 mb-10px">
                                                                Giá Bán: <?php echo e(number_format($value->price, 0, ',', '.')); ?>

                                                                vnđ</span>
                                                        </div>

                                                        <div
                                                            class="d-blog align-items-center justify-content-between d-xl-block mt-2 mt-md-0 w-350px truncate">
                                                            <span class="text-muted d-flex align-items-center mt-md-2"><i
                                                                    data-feather="map-pin"
                                                                    class="fea icon-sm me-1 align-middle"></i><?php echo e($value->objCategory->name); ?></span>
                                                            <span class="d-flex fw-medium mt-md-2 mb-10px mb-md-2"
                                                                style="font-size: 11.5px;"><?php echo e($address); ?></span>
                                                        </div>

                                                        <div class="mt-3 mt-md-0">
                                                            <a href="<?php echo e(route('view_detail_group', $value->slugGroup)); ?>"
                                                                class="btn btn-sm btn-primary w-full">Đăng Ký</a>
                                                        </div>
                                                    </div>
                                                </div><!--end col-->
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div><!--end row-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php elseif(isset($filters['province']) && !isset($filters['district']) && !isset($filters['wards'])): ?>
                <div class="row g-2">
                    <?php $__currentLoopData = $searchResult; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $type = $typeHTML[$value->type] ?? [
                                'name' => 'Không Xác Định',
                                'color' => '#000000',
                            ];
                            $typeName = $type['name'];
                            $typeColor = $type['color'];
                            $address = '';

                            // Kiểm tra và thêm thông tin thành phố
                            if (isset($value->province)) {
                                $address .= $value->province;
                            }

                            // Kiểm tra và thêm thông tin quận huyện
                            if (isset($value->district)) {
                                if ($address !== '') {
                                    $address .= ' - ';
                                }
                                $address .= $value->district;
                            }

                            // Kiểm tra và thêm thông tin phường xã
                            if (isset($value->wards)) {
                                if ($address !== '') {
                                    $address .= ' - ';
                                }
                                $address .= $value->wards;
                            }
                        ?>
                        <div class="col-xl-12 col-lg-4 col-md-6 col-sm-6 col-12">
                            <div
                                class="job-post job-post-list rounded shadow p-3 d-xl-flex align-items-center justify-content-between position-relative">
                                <div class="d-flex align-items-center w-350px">
                                    <div>
                                        <div class="truncate-mobile">
                                            <a href="<?php echo e($value->linkGroup); ?>" target="_blank"
                                                class="h5 title text-dark"><?php echo e($value->nameGroup); ?></a>

                                        </div>
                                        <span class="d-flex fw-medium mt-md-2"><?php echo e($value->account_group); ?> Thành
                                            Viên</span>
                                    </div>
                                </div>

                                <div
                                    class="d-flex align-items-center justify-content-between d-xl-block mt-3 mt-md-0 w-120px">
                                    <span class="badge rounded-pill <?php echo e($typeColor); ?>"><?php echo e($typeName); ?></span>
                                    <span class="text-muted d-flex align-items-center fw-medium mt-lg-2"><i
                                            class="fea icon-sm me-1 align-middle fas fa-map-signs"></i><?php echo e($value->category); ?></span>
                                </div>

                                <div
                                    class="d-blog align-items-center justify-content-between d-xl-block mt-3 mt-md-0 w-280px">
                                    <span class="text-muted d-flex align-items-center fw-medium mt-md-2">
                                        Giá Thuê: <?php echo e(number_format($value->rent_cost, 0, ',', '.')); ?> vnđ / tháng</span>
                                    <span class="text-muted d-flex align-items-center fw-medium mt-md-2 mb-10px">
                                        Giá Bán: <?php echo e(number_format($value->price, 0, ',', '.')); ?> vnđ</span>
                                </div>

                                <div
                                    class="d-blog align-items-center justify-content-between d-xl-block mt-2 mt-md-0 w-350px truncate">
                                    <span class="text-muted d-flex align-items-center mt-md-2"><i data-feather="map-pin"
                                            class="fea icon-sm me-1 align-middle"></i><?php echo e($value->objCategory->name); ?></span>
                                    <span class="d-flex fw-medium mt-md-2 mb-10px mb-md-2"
                                        style="font-size: 11.5px;"><?php echo e($address); ?></span>
                                </div>

                                <div class="mt-3 mt-md-0">
                                    <a href="<?php echo e(route('view_detail_group', $value->slugGroup)); ?>"
                                        class="btn btn-sm btn-primary w-full">Đăng Ký</a>
                                </div>
                            </div>
                        </div><!--end col-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div><!--end row-->
                <div class="row" style="margin: 0px 0px 50px 0px;">
                    <div class="col-12 mt-4 pt-2" style="text-align: center;">
                        <?php if(ceil($searchResult->total() / 12) > 1): ?>
                            <?php
                            $current_page = isset($_GET['page']) ? $_GET['page'] : '1';
                            $page = $current_page - 1;
                            $pages = $current_page + 1;
                            $maxPage = ceil($searchResult->total() / 12);
                            $check = $current_page;
                            ?>
                            <?php if($current_page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo e($current_page - 1); ?>" aria-label="Previous">
                                        <span aria-hidden="true"><i class="mdi mdi-chevron-left fs-6"></i></span>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php for($i = max(1, $current_page - 1); $i <= min($maxPage, $current_page + 2); $i++): ?>
                                <li class="page-item <?php echo e($i == $searchResult->currentPage() ? 'active' : ''); ?>"><a
                                        class="page-link" href="?page=<?php echo e($i); ?>"><?php echo e($i); ?></a></li>
                            <?php endfor; ?>

                            <?php if($current_page < $maxPage): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo e($current_page + 1); ?>" aria-label="Next">
                                        <span aria-hidden="true"><i class="mdi mdi-chevron-right fs-6"></i></span>
                                    </a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                        <?php endif; ?>
                    </div><!--end col-->
                </div><!--end row-->
            <?php else: ?>
                <div class="row g-2">
                    <?php $__currentLoopData = $searchResult; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $type = $typeHTML[$value->type] ?? [
                                'name' => 'Không Xác Định',
                                'color' => '#000000',
                            ];
                            $typeName = $type['name'];
                            $typeColor = $type['color'];
                            $address = '';

                            // Kiểm tra và thêm thông tin thành phố
                            if (isset($value->province)) {
                                $address .= $value->province;
                            }

                            // Kiểm tra và thêm thông tin quận huyện
                            if (isset($value->district)) {
                                if ($address !== '') {
                                    $address .= ' - ';
                                }
                                $address .= $value->district;
                            }

                            // Kiểm tra và thêm thông tin phường xã
                            if (isset($value->wards)) {
                                if ($address !== '') {
                                    $address .= ' - ';
                                }
                                $address .= $value->wards;
                            }
                        ?>
                        <div class="col-xl-12 col-lg-4 col-md-6 col-sm-6 col-12">
                            <div
                                class="job-post job-post-list rounded shadow p-3 d-xl-flex align-items-center justify-content-between position-relative">
                                <div class="d-flex align-items-center w-350px">
                                    <div>
                                        <div class="truncate-mobile">
                                            <a href="<?php echo e($value->linkGroup); ?>" target="_blank"
                                                class="h5 title text-dark"><?php echo e($value->nameGroup); ?></a>

                                        </div>
                                        <span class="d-flex fw-medium mt-md-2"><?php echo e($value->account_group); ?> Thành
                                            Viên</span>
                                    </div>
                                </div>

                                <div
                                    class="d-flex align-items-center justify-content-between d-xl-block mt-3 mt-md-0 w-120px">
                                    <span class="badge rounded-pill <?php echo e($typeColor); ?>"><?php echo e($typeName); ?></span>
                                    <span class="text-muted d-flex align-items-center fw-medium mt-lg-2"><i
                                            class="fea icon-sm me-1 align-middle fas fa-map-signs"></i><?php echo e($value->category); ?></span>
                                </div>

                                <div
                                    class="d-blog align-items-center justify-content-between d-xl-block mt-3 mt-md-0 w-280px">
                                    <span class="text-muted d-flex align-items-center fw-medium mt-md-2">
                                        Giá Thuê: <?php echo e(number_format($value->rent_cost, 0, ',', '.')); ?> vnđ / tháng</span>
                                    <span class="text-muted d-flex align-items-center fw-medium mt-md-2 mb-10px">
                                        Giá Bán: <?php echo e(number_format($value->price, 0, ',', '.')); ?> vnđ</span>
                                </div>

                                <div
                                    class="d-blog align-items-center justify-content-between d-xl-block mt-2 mt-md-0 w-350px truncate">
                                    <span class="text-muted d-flex align-items-center mt-md-2"><i data-feather="map-pin"
                                            class="fea icon-sm me-1 align-middle"></i><?php echo e($value->objCategory->name); ?></span>
                                    <span class="d-flex fw-medium mt-md-2 mb-10px mb-md-2"
                                        style="font-size: 11.5px;"><?php echo e($address); ?></span>
                                </div>

                                <div class="mt-3 mt-md-0">
                                    <a href="<?php echo e(route('view_detail_group', $value->slugGroup)); ?>"
                                        class="btn btn-sm btn-primary w-full">Đăng Ký</a>
                                </div>
                            </div>
                        </div><!--end col-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div><!--end row-->
                <div class="row" style="margin: 0px 0px 50px 0px;">
                    <div class="col-12 mt-4 pt-2" style="text-align: center;">
                        <?php if(ceil($searchResult->total() / 12) > 1): ?>
                            <?php
                            $current_page = isset($_GET['page']) ? $_GET['page'] : '1';
                            $page = $current_page - 1;
                            $pages = $current_page + 1;
                            $maxPage = ceil($searchResult->total() / 12);
                            $check = $current_page;
                            ?>
                            <?php if($current_page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo e($current_page - 1); ?>" aria-label="Previous">
                                        <span aria-hidden="true"><i class="mdi mdi-chevron-left fs-6"></i></span>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php for($i = max(1, $current_page - 1); $i <= min($maxPage, $current_page + 2); $i++): ?>
                                <li class="page-item <?php echo e($i == $searchResult->currentPage() ? 'active' : ''); ?>"><a
                                        class="page-link" href="?page=<?php echo e($i); ?>"><?php echo e($i); ?></a></li>
                            <?php endfor; ?>

                            <?php if($current_page < $maxPage): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo e($current_page + 1); ?>" aria-label="Next">
                                        <span aria-hidden="true"><i class="mdi mdi-chevron-right fs-6"></i></span>
                                    </a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                        <?php endif; ?>
                    </div><!--end col-->
                </div><!--end row-->
            <?php endif; ?>
        </div><!--end container-->
    </section><!--end section-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('view_js'); ?>
    <?php echo $__env->make('FEuser.Layout.Fooder.JS_Menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('FEuser.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\web_for_group\app-group\resources\views/FEuser/Pages/List_Group/index_list.blade.php ENDPATH**/ ?>