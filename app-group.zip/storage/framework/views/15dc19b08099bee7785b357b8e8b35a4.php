<?php if(Session::get('success')): ?>
    <script>
        swal("<?php echo e(Session::get('success')); ?>", "Thông Báo Từ Hệ Thống!", 'success', {
            button: true,
            button: "OK",
            timer: 50000,
            dangerMode: true,
        })
    </script>
<?php endif; ?>
<?php /**PATH D:\web_for_group\app-group\resources\views/FEuser/Sweetalert/success.blade.php ENDPATH**/ ?>