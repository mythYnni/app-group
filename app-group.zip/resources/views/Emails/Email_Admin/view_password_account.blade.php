<!DOCTYPE html
    PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" xmlns:o="urn:schemas-microsoft-com:office:office">

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1" name="viewport">
    <meta name="x-apple-disable-message-reformatting">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="telephone=no" name="format-detection">
    <title></title>
</head>

<body>
    <div dir="ltr" class="es-wrapper-color">
        <table class="es-wrapper" width="100%" cellspacing="0" cellpadding="0">
            <tbody>
                <tr>
                    <td class="esd-email-paddings" valign="top">
                        <table cellpadding="0" cellspacing="0" class="es-header esd-header-popover" align="center">
                            <tbody>
                                <tr>
                                    <td class="esd-stripe esd-synchronizable-module" align="center">
                                        <table bgcolor="rgba(0, 0, 0, 0)" class="es-header-body" align="center"
                                            cellpadding="0" cellspacing="0" width="490">
                                            <tbody>
                                                <tr>
                                                    <td class="esd-structure es-p10t es-p10b es-p20r es-p20l"
                                                        align="left">
                                                        <table cellpadding="0" cellspacing="0" width="100%">
                                                            <tbody>
                                                                <tr>
                                                                    <td width="450"
                                                                        class="es-m-p0r esd-container-frame"
                                                                        valign="top" align="center">
                                                                        <table cellpadding="0" cellspacing="0"
                                                                            width="100%">
                                                                            <tbody>
                                                                                <tr class="es-visible-simple-html-only">
                                                                                    <td align="center"
                                                                                        class="esd-block-image es-p10t es-p10b"
                                                                                        style="font-size:0px;background: white; padding: 20px;">
                                                                                        <a target="_blank">
                                                                                            <img src="https://fcjcsvn.stripocdn.email/content/guids/CABINET_a3448362093fd4087f87ff42df4565c1/images/78501618239341906.png"
                                                                                                style="display: block;"
                                                                                                width="100">
                                                                                        </a>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <table cellpadding="0" cellspacing="0" class="es-content" align="center">
                            <tbody>
                                <tr>
                                    <td class="esd-stripe" align="center">
                                        <table bgcolor="#fefcfc" class="es-content-body" align="center" cellpadding="0"
                                            cellspacing="0" width="490" style="background-color: #fefcfc;">
                                            <tbody>
                                                <tr>
                                                    <td class="esd-structure es-p10t es-p10b es-p20r es-p20l"
                                                        align="left">
                                                        <table cellpadding="0" cellspacing="0" width="100%">
                                                            <tbody>
                                                                <tr>
                                                                    <td width="450" class="esd-container-frame"
                                                                        align="center" valign="top">
                                                                        <table cellpadding="0" cellspacing="0"
                                                                            width="100%"
                                                                            style="border-left:2px dashed #cccccc;border-right:2px dashed #cccccc;border-top:2px dashed #cccccc;border-bottom:2px dashed #cccccc;border-radius: 5px; border-collapse: separate;">
                                                                            <tbody>
                                                                                <tr class="es-visible-simple-html-only">
                                                                                    <td align="center"
                                                                                        class="esd-block-text es-m-txt-c h-auto"
                                                                                        esd-links-underline="none"
                                                                                        height="140">
                                                                                        <p style="line-height: 200%;">
                                                                                            <strong
                                                                                                style="
                                                                                            font-size: 16px;">Thông
                                                                                                Tin Tài Khoản
                                                                                                Đăng Nhập
                                                                                                Chiasekhoahoc.vn</strong><br>Hãy
                                                                                            Đăng Nhập Và Cập Nhật Lại
                                                                                            Mật Khẩu Của Bạn Để Bảo Mật
                                                                                            Thông Tin Của Bạn Khỏi Những
                                                                                            Người Xấu Nhé.
                                                                                            <br><strong>Email:
                                                                                                {{ $mailData['email'] }}
                                                                                                <br> Mật Khẩu:
                                                                                                {{ $mailData['password'] }}</strong><strong></strong>
                                                                                        </p>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <table cellpadding="0" cellspacing="0" class="es-footer esd-footer-popover" align="center">
                            <tbody>
                                <tr>
                                    <td class="esd-stripe esd-synchronizable-module" align="center">
                                        <table class="es-footer-body" align="center" cellpadding="0" cellspacing="0"
                                            width="490" style="background-color: transparent;">
                                            <tbody>
                                                <tr>
                                                    <td class="esd-structure es-p20t es-p20b es-p20r es-p20l"
                                                        align="left">
                                                        <table cellpadding="0" cellspacing="0" width="100%">
                                                            <tbody>
                                                                <tr>
                                                                    <td width="450" class="esd-container-frame"
                                                                        align="left">
                                                                        <table cellpadding="0" cellspacing="0"
                                                                            width="100%">
                                                                            <tbody>
                                                                                <tr>
                                                                                    <td align="center"
                                                                                        class="esd-block-text es-p35b">
                                                                                        <p style="line-height: 200%;">©
                                                                                            2023 Edurock - Khóa Học Sinh
                                                                                            Viên | Chia Sẻ Khóa Học
                                                                                            Online Qua Driver.</p>
                                                                                    </td>
                                                                                </tr>
                                                                            </tbody>
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</body>

</html>
