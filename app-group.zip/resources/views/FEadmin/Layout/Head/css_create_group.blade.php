<!-- [Favicon] icon -->
<link rel="stylesheet" href="{{ url('assets') }}/fonts/inter/inter.css" id="main-font-link" />
<!-- [Tabler Icons] https://tablericons.com -->
<link rel="stylesheet" href="{{ url('assets') }}/fonts/tabler-icons.min.css">
<!-- [Feather Icons] https://feathericons.com -->
<link rel="stylesheet" href="{{ url('assets') }}/fonts/feather.css">
<!-- [Font Awesome Icons] https://fontawesome.com/icons -->
<link rel="stylesheet" href="{{ url('assets') }}/fonts/fontawesome.css">
<!-- [Material Icons] https://fonts.google.com/icons -->
<link rel="stylesheet" href="{{ url('assets') }}/fonts/material.css">
<!-- [Template CSS Files] -->
<link rel="stylesheet" href="{{ url('assets') }}/css/style.css" id="main-style-link">
<link rel="stylesheet" href="{{ url('assets') }}/css/style-preset.css">
