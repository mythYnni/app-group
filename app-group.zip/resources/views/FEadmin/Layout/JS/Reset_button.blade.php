<script>
    document.getElementById('resetBtn').addEventListener('click', function() {
        document.getElementById('formReset').reset(); // Thay yourFormId bằng id của form của bạn
    });
</script>
