 <!-- Back to top -->
 <a href="#" onclick="topFunction()" id="back-to-top" class="back-to-top rounded fs-5"><i data-feather="arrow-up"
         class="fea icon-sm align-middle"></i></a>
 <!-- Back to top -->

 <!-- JAVASCRIPTS -->
 <script src="{{ url('assets') }}/user/js/bootstrap.bundle.min.js"></script>
 <script src="{{ url('assets') }}/user/js/choices.min.js"></script>
 <script src="{{ url('assets') }}/user/js/feather.min.js"></script>
 <!-- Custom -->
 <script src="{{ url('assets') }}/user/js/plugins.init.js"></script>
 <script src="{{ url('assets') }}/user/js/app.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"
     integrity="sha512-AA1Bzp5Q0K1KanKKmvN/4d3IRKVlv9PYgwFPvm32nPO6QS8yH1HO7LbgB1pgiOxPtfeg5zEn2ba64MUcqJx6CA=="
     crossorigin="anonymous" referrerpolicy="no-referrer"></script>
