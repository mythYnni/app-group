<!-- Bootstrap core CSS -->
<link href="{{ url('assets') }}/user/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
<link href="{{ url('assets') }}/user/css/choices.min.css" rel="stylesheet" />
<link href="{{ url('assets') }}/user/css/materialdesignicons.min.css" rel="stylesheet" type="text/css" />
<!-- Custom  Css -->
<link href="{{ url('assets') }}/user/css/style.min.css" rel="stylesheet" type="text/css" id="theme-opt" />